<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Your CSS and other necessary links -->
</head>
<body>
  <div class="container-1">
    <h2 class="form-heading">Safe File Checker</h2>
    <input type="file" id="fileInput">
    <button onclick="scanFile()">Scan File</button>
    <div id="scanResults"></div>
  </div>

  <script>
    function scanFile() {
      var fileInput = document.getElementById('fileInput');
      var file = fileInput.files[0];
      if (!file) {
        alert('Please select a file.');
        return;
      }

      var formData = new FormData();
      formData.append('file', file);

      var xhr = new XMLHttpRequest();
      xhr.open('POST', 'scan.php', true);
      xhr.onload = function () {
        if (xhr.status === 200) {
          document.getElementById('scanResults').innerHTML = xhr.responseText;
        } else {
          alert('Error occurred while scanning the file.');
        }
      };
      xhr.send(formData);
    }
  </script>
</body>
</html>
